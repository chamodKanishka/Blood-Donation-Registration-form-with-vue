<script>
import moment from 'moment';


export default {
  data() {
    return {
      currentTime: moment().format('HH:mm:ss'),
    };
  },
  created() {
    this.startClock();
  },
  methods: {
    startClock() {
      setInterval(() => {
        this.currentTime = moment().format('HH:mm:ss');
      }, 1000);
    },
  },
};
</script>

<template>
  <head>
  </head>
  <body class="main">

    <header class="d-flex  align-items-center justify-content-center justify-content-md-between border-bottom">
      <img class="header-image" src="../assets/giphy.webp">
       <p class="head">Japanese National Blood Donation Program</p>
      <img class="header-image" src="../assets/Flag.gif">
    </header>
    <div class="row g-5">
      <div class="col-lg-3">
        <img src="../assets/blood_donation.avif" alt="bldonate" id="backimg" />
      </div>
      <div class="col-md-7 col-lg-6">
        <br>
        <h4 class="mb-3">Registration Form for New Donetors</h4>
        <form class="needs-validation" novalidate="">
          <div class="row g-3">
            <div class="col-sm-4">
              <label for="firstName" class="form-label">First name</label>
              <input type="text" class="form-control" id="firstName" placeholder="" value="" required="">
              <div class="invalid-feedback">
                Valid first name is required.
              </div>
            </div>
            <div class="col-sm-4">
              <label for="middleName" class="form-label">Middle name (if you have)</label>
              <input type="text" class="form-control" id="middleName" placeholder="" value="" required="">
              <div class="invalid-feedback">
                Valid last name is required.
              </div>
            </div>
            <div class="col-sm-4">
              <label for="lastName" class="form-label">Last name</label>
              <input type="text" class="form-control" id="lastName" placeholder="" value="" required="">
              <div class="invalid-feedback">
                Valid last name is required.
              </div>
            </div>

            <div class="col-md-5">
              <label for="country" class="form-label">Nationality</label>
              <select class="form-select" id="country" required="">
                <option value="">Choose...</option>
                <option>Japanese(日本人)</option>
              </select>
              <div class="invalid-feedback">
                Please select a valid city.
              </div>
            </div>

            <div class="col-12">
              <label for="phone" class="form-label">Phone Number</label>
              <input type="text" class="form-control" id="phone" placeholder="123-4567-7891" required="">
              <div class="invalid-feedback">
                Please enter your address.
              </div>
            </div>

            <div class="col-12">
              <label for="email" class="form-label">Email <span class="text-body-secondary">(Optional)</span></label>
              <input type="email" class="form-control" id="email" placeholder="you@example.com">
              <div class="invalid-feedback">
                Please enter a valid email address.
              </div>
            </div>
            <hr class="my-4">
            <h3>Address</h3>
            <div class="col-md-5">
              <label for="country" class="form-label">Perfecture</label>
              <select class="form-select" id="country" required="">
                <option value="">Choose...</option>
                <option>Kyoto(京都)</option>
              </select>
              <div class="invalid-feedback">
                Please select a valid city.
              </div>
            </div>

            <div class="col-md-4">
              <label for="state" class="form-label">City</label>
              <select class="form-select" id="state" required="">
                <option value="">Choose...</option>
                <option>Hakumanben(百万遍)</option>
              </select>
              <div class="invalid-feedback">
                Please provide a valid state.
              </div>
            </div>

            <div class="col-md-3">
              <label for="zip" class="form-label">Postal Code</label>
              <input type="text" class="form-control" id="zip" placeholder="" required="">
              <div class="invalid-feedback">
                Zip code required.
              </div>
            </div>
          </div>

            <div class="col-12">
              <label for="address" class="form-label">Address</label>
              <input type="text" class="form-control" id="address" placeholder="1234 Main St" required="">
              <div class="invalid-feedback">
                Please enter your address.
              </div>
            </div>
          <hr class="my-4">
          <div class="row gy-2">
          <h4 class="">Blood Type</h4>

          <div class="col-sm-6">
            <div class="form-check">
              <input id="credit" name="paymentMethod" type="radio" class="form-check-input" checked="" required="">
              <label class="form-check-label" for="A">A+</label>
            </div>
            <div class="form-check">
              <input id="debit" name="paymentMethod" type="radio" class="form-check-input" required="">
              <label class="form-check-label" for="B">B+</label>
            </div>
            <div class="form-check">
              <input id="paypal" name="paymentMethod" type="radio" class="form-check-input" required="">
              <label class="form-check-label" for="paypal">AB+</label>
            </div>
            <div class="form-check">
              <input id="paypal" name="paymentMethod" type="radio" class="form-check-input" required="">
              <label class="form-check-label" for="paypal">O+</label>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="form-check">
              <input id="credit" name="paymentMethod" type="radio" class="form-check-input" checked="" required="">
              <label class="form-check-label" for="A">A-</label>
            </div>
            <div class="form-check">
              <input id="debit" name="paymentMethod" type="radio" class="form-check-input" required="">
              <label class="form-check-label" for="B">B-</label>
            </div>
            <div class="form-check">
              <input id="paypal" name="paymentMethod" type="radio" class="form-check-input" required="">
              <label class="form-check-label" for="paypal">AB-</label>
            </div>
            <div class="form-check">
              <input id="paypal" name="paymentMethod" type="radio" class="form-check-input" required="">
              <label class="form-check-label" for="paypal">O-</label>
            </div>
          </div>
</div>

          <hr class="my-4"><br>
          <div class="form-check">
            <input type="checkbox" class="form-check-input" id="same-address">
            <label class="form-check-label" for="same-address">I am 18+ years old</label>
          </div>
          <br>

          <div class="row gy-3">

          </div>

          <hr class="my-4">

          <button class="w-100 btn btn-primary btn-lg" type="submit">Submit</button>
        </form>
      </div>
      <div class="col-lg-3">
    <div class="clock">
    {{ currentTime }}
  </div>
      </div>
    </div>
  </body>
  <footer class="d-flex flex-wrap align-items-center justify-content-center mb-4 mb-5">
  </footer>
</template>

<style scoped>
.head{
  color: darkred;
  font-weight: 900;
  font-size: xxx-large;
  align-items: center;
  font-family: "Sinhala Sangam MN";
}
header{
  background-color: black;
}
.header-image {
  width: 120px; /* Adjust the width as needed */
  height: 100px; /* Maintains the aspect ratio */
  margin-left:  30px;
  margin-right: 30px;

}
.main{
  color: black;
}

.hover-element {
  width: 200px;
  height: 50px;
  background-color: #ddd;
  text-align: center;
  line-height: 50px;
  cursor: pointer;
  margin-bottom: 10px;
}

.clock {
  font-size: 2em;
  font-family: 'Arial', sans-serif;
}

</style>
