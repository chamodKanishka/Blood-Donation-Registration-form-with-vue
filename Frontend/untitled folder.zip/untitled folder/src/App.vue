<script setup>
import Landing from "@/components/Landing.vue";
</script>

<template>
  <header>
    <div class="wrapper">
      <Landing/>
    </div>
  </header>

  <main>
  </main>
</template>

<style scoped>

</style>
